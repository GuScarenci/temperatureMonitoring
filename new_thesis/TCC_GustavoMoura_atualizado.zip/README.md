# TCC no modelo ICMC

Arquivo principal: `thesis.tex`. Conteúdo transferido de `thesis/paper`, preservando a classe e a identidade visual do modelo ICMC.

Compile com `make`; o PDF será gerado em `build/thesis.pdf`. No Overleaf, selecione `thesis.tex` como documento principal e pdfLaTeX como compilador.

Os quatro capítulos originais foram preservados; metodologia e resultados integram Desenvolvimento. O material atualizado está em `sections`, `tables`, `figures`, `metadata.tex` e `references.bib`. Os arquivos antigos em `tex/capitulos` não são utilizados.
